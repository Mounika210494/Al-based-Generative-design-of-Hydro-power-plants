# AI-Based Generative Design of Hydropower Plants

## 📌 Overview
This project introduces an AI-powered approach to conceptual hydropower plant design.  
It automates **site selection**, **turbine configuration**, and **layout design** using AI-based generative algorithms.

## 🚀 Features
- AI-driven design generation
- Automated evaluation of multiple candidate layouts
- Visualization (bar charts, flowcharts, ER diagrams)
- Database schema for storing river, turbine, and plant data
- Outputs stored for future retraining and analysis

## 📂 Project Structure
```
AI_Generative_Hydro/
│── main.py
│── requirements.txt
│── README.md
│── .gitignore
│── docs/
│   ├── AI_Generative_Hydro_Project-2.pdf
│── db/
│   └── schema.sql
│── outputs/
│   ├── best_design.txt
│   ├── output_chart.png
```

## ⚙️ Installation
```bash
pip install -r requirements.txt
```

## ▶️ Usage
```bash
python main.py
```

## 📊 Example Output
```
Best Design: {'river': 'Godavari', 'turbine': 'Francis', 'num_turbines': 8, 'output': 5100.0, 'cost': 12.0}
```

## 📖 Documentation
📄 [View Full Project Report](docs/AI_Generative_Hydro_Project-2.pdf)
