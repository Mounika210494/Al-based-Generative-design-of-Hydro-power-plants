CREATE TABLE River (
    river_id INT PRIMARY KEY,
    name VARCHAR(100),
    avg_flow_rate FLOAT,
    seasonal_variation FLOAT
);

CREATE TABLE Turbine (
    turbine_id INT PRIMARY KEY,
    type VARCHAR(50),
    capacity FLOAT,
    efficiency FLOAT
);

CREATE TABLE PlantDesign (
    design_id INT PRIMARY KEY,
    location VARCHAR(100),
    estimated_output FLOAT,
    cost FLOAT,
    river_id INT,
    turbine_id INT,
    FOREIGN KEY (river_id) REFERENCES River(river_id),
    FOREIGN KEY (turbine_id) REFERENCES Turbine(turbine_id)
);
